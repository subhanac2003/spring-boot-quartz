# spring-boot-quartz-demo
Spring Boot + Quartz + Angular2 demo application. 

It explains how to schedule a cron job, how to pause a job, resume a job, edit quartz job etc. 
It used PostgreSQL as database for storing quartz jobs and triggers.

Detailed explanation: http://javabypatel.blogspot.sg/2017/10/quartz-scheduler-spring-boot-example.html

It contains UI application built on Angular2 for scheduling a job.
It also helps in Editing a job, you can also pause a job, resume a job, delete a job etc.

 ![output-image](https://1.bp.blogspot.com/-wdA6K1d_bj8/Wdun-8Sj7zI/AAAAAAAACIE/OXwEYjvnCWsHDaz7PGyLuzUr_jAiR6JagCLcBGAs/s1600/spring-quartz-scheduler-angular2-ui.PNG) 
