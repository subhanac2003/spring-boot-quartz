
export class Job{
    id: number 
    name: string;
    startDate: string;
}

